import { Request, Response } from 'express';
import { Product } from '../../models/Product';

//é responsavel por criar novos produtos, caso o modo de criação esteja correto retor 201,
//caso haja algum erro retorna 500 
export async function createProduct(req: Request, res: Response) {
	try {
		const imagePath = req.file?.filename;
		const { name, description, price, category, ingredients } = req.body;//pega as informações solicitadas

		const product = await Product.create({//cria um produto novo com as imformações fornecidas
			name,
			description,
			imagePath,
			price: Number(price),
			category,
			ingredients:ingredients ? JSON.parse(ingredients): [],
		});

		res.status(201).json(product);//se caso for registrado com sucesso retorna 201
	} catch (error) {//se ouver erro retorna 500
		console.log(error);
		res.sendStatus(500);
	}
}