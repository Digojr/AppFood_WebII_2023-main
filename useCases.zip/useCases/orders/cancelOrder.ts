import { Request, Response } from 'express';
import { Order } from '../../models/Order';

// Controlador para cancelar um pedido
export async function cancelOrder(req: Request, res: Response) {
	try {
		const { orderId } = req.params;//pega o id do pedido
		await Order.findByIdAndDelete(orderId);// Encontra e exclui o pedido com base no ID fornecido
		res.sendStatus(204);//se ta tudo certo retorna 204

	} catch (error) {//caso haja erro retorna 500
		console.log(error);
		res.sendStatus(500);
	}
}